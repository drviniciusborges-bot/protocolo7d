# Ideias de Design - Protocolo 7D: Cura Caseira

## Contexto do Projeto
Landing page de vendas para um protocolo natural de tratamento de ISTs. O público alvo valoriza **discrição, rapidez, eficácia e confiança**. A proposta é transformar um problema delicado em uma solução acessível e empoderada.

---

## <response>
### Ideia 1: "Wellness Minimalista com Autoridade Científica"
**Probabilidade: 0.08**

**Design Movement:** Modern Minimalism + Science-Forward Design

**Core Principles:**
- Clareza absoluta: cada elemento comunica um propósito específico
- Confiança através da transparência: dados, estrutura e linguagem científica
- Espaço negativo generoso: respira e não pressiona
- Hierarquia visual rigorosa: guia o olhar naturalmente através da jornada

**Color Philosophy:**
- Paleta: Azul profundo (#1e3a8a) + Verde menta (#10b981) + Branco/Off-white + Cinza neutro
- Intenção: Azul transmite confiança médica e profissionalismo; verde menta evoca natureza e cura; cinza mantém a sobriedade
- Uso: Fundos limpos, acentos estratégicos em CTA, tipografia em tons neutros

**Layout Paradigm:**
- Estrutura vertical com "breathing room" entre seções
- Cards informativos com bordas sutis e sombras minimalistas
- Asymmetric grid: imagens/ícones à esquerda, texto à direita (alternando)
- Seções full-width com padding generoso

**Signature Elements:**
1. Ícones geométricos customizados (círculos, linhas, formas abstratas)
2. Timeline visual dos 7 dias em design linear e clean
3. Badges/selos de confiança com tipografia serif elegante

**Interaction Philosophy:**
- Transições suaves ao scroll (fade-in, slide-up)
- Hover effects sutis em CTAs (mudança de cor, elevação leve)
- Micro-interações: checkmarks animados ao passar por benefícios

**Animation:**
- Scroll-triggered fade-ins com delay escalonado
- Números contadores para estatísticas (1.2M → 1.2M ao scroll)
- CTA pulsa levemente para atrair atenção sem ser agressivo

**Typography System:**
- Display: Playfair Display (serif elegante) para títulos principais
- Body: Inter (sans-serif clean) para corpo de texto
- Hierarchy: 3.5rem (h1) → 2.25rem (h2) → 1.5rem (h3) → 1rem (body)

---

## <response>
### Ideia 2: "Wellness Emocional com Narrativa Humana"
**Probabilidade: 0.07**

**Design Movement:** Emotional Design + Storytelling-First

**Core Principles:**
- Humanidade em primeiro lugar: depoimentos, histórias reais, conexão emocional
- Warmth visual: cores quentes, ilustrações amigáveis, tom conversacional
- Progressão narrativa: cada seção conta parte de uma história de transformação
- Inclusão visual: diversidade de pessoas, expressões autênticas

**Color Philosophy:**
- Paleta: Coral quente (#ff6b6b) + Pêssego (#ffa500) + Creme (#fffacd) + Roxo suave (#d4a5d4)
- Intenção: Coral é acolhedor e energético; pêssego evoca natureza e calor; roxo suave adiciona mistério/transformação
- Uso: Fundos com gradientes suaves, textos em tons quentes, CTAs em coral vibrante

**Layout Paradigm:**
- Diagonal cuts e organic shapes para quebrar linearidade
- Seções com fundo colorido alternando com branco
- Imagens grandes e emotivas como protagonistas (não suporte)
- Testimonials em cards com foto grande + nome + história breve

**Signature Elements:**
1. Organic shapes/blobs como divisores de seção
2. Ilustrações hand-drawn style (não fotográficas)
3. Quotes em tipografia grande e destaque visual

**Interaction Philosophy:**
- Animações ao entrar na viewport: cards deslizam, números contam
- Hover em testimonials: foto amplia, sombra aumenta
- CTAs com movimento de "pulsação" suave

**Animation:**
- Parallax leve em seções com imagens
- Testimonials com flip/rotate ao hover
- Scroll-triggered grow animations para elementos

**Typography System:**
- Display: Poppins Bold (rounded, friendly) para títulos
- Body: Lato (warm, legível) para corpo
- Quotes: Merriweather (serif warm) para depoimentos
- Hierarchy: 4rem (h1) → 2.5rem (h2) → 1.75rem (h3) → 1rem (body)

---

## <response>
### Ideia 3: "Premium Health Tech com Autoridade Inovadora"
**Probabilidade: 0.06**

**Design Movement:** Luxury Tech + Modern Wellness

**Core Principles:**
- Sofisticação visual: detalhes refinados, uso estratégico de ouro/prata
- Inovação percebida: design futurista mas acessível
- Confiança premium: tipografia elegante, espaçamento generoso
- Exclusividade: "vagas limitadas" refletida no design (elementos raros, paleta restrita)

**Color Philosophy:**
- Paleta: Preto profundo (#0f172a) + Ouro (#d4af37) + Branco puro + Cinza grafite (#374151)
- Intenção: Preto + ouro = luxo e exclusividade; branco = clareza; cinza = sofisticação
- Uso: Fundos escuros com acentos dourados, tipografia branca/ouro, CTAs em ouro

**Layout Paradigm:**
- Grid simétrico mas com elementos assimétricos dentro
- Seções com fundo escuro e conteúdo centralizado
- Imagens em frames dourados ou com bordas refinadas
- Espaçamento generoso (padding 6-8rem entre seções)

**Signature Elements:**
1. Linhas douradas finas como separadores/decoração
2. Badges premium com moldura dourada
3. Números/estatísticas em tipografia grande e ouro

**Interaction Philosophy:**
- Transições lentas e deliberadas (300-500ms)
- Hover em elementos revela detalhes dourados
- CTAs com efeito de "elevação" e brilho

**Animation:**
- Fade-ins lentos ao scroll (não rápidos)
- Elementos dourados com subtle glow
- CTAs com efeito de "shimmer" (brilho passante)

**Typography System:**
- Display: Cormorant Garamond (serif luxury) para títulos
- Body: Lato (clean, legível) para corpo
- Accent: Montserrat (geometric, modern) para labels
- Hierarchy: 3.75rem (h1) → 2.5rem (h2) → 1.5rem (h3) → 1rem (body)

---

## Resumo Comparativo

| Aspecto | Ideia 1 (Minimalista) | Ideia 2 (Emocional) | Ideia 3 (Premium) |
|---------|----------------------|-------------------|-------------------|
| **Tom** | Profissional, confiável | Acolhedor, humano | Luxuoso, exclusivo |
| **Público** | Busca clareza e eficácia | Busca conexão e esperança | Busca exclusividade |
| **Velocidade Percebida** | Rápida (limpo) | Transformadora (narrativa) | Deliberada (premium) |
| **Risco** | Pode parecer frio | Pode parecer genérico | Pode parecer inacessível |
| **Melhor Para** | Confiança técnica | Engajamento emocional | Diferenciação premium |

