import { Button } from "@/components/ui/button";
import { Check, Lock, Zap, Heart, Users } from "lucide-react";

/**
 * Design Philosophy: Wellness Emocional com Narrativa Humana
 * Público: Homens que buscam discrição, rapidez e retomada do controle
 * Paleta: Coral (#ff6b6b) + Pêssego (#ffa500) + Creme (#fffacd) + Roxo suave (#d4a5d4)
 * Tipografia: Poppins (display), Lato (body), Merriweather (quotes)
 * Layout: Narrativa progressiva, cards emocionais, testimonials autênticos
 * 
 * Imagens: Usar conteúdo visual do PDF fornecido
 */

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* HERO SECTION */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-20 bg-gradient-to-b from-secondary/30 via-background to-background">
        <div className="container relative z-10 max-w-3xl mx-auto px-4 text-center">
          <div className="mb-6 inline-block">
            <span className="text-sm font-semibold text-primary px-4 py-2 bg-primary/10 rounded-full">
              ✨ Solução Comprovada em 7 Dias
            </span>
          </div>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            A Transformação da Sua Saúde Começa <span className="text-primary">Agora!</span>
          </h1>

          <p className="text-xl md:text-2xl text-foreground/80 mb-8 leading-relaxed">
            Protocolo 7D: Cura Caseira Para Doenças IST
          </p>

          <p className="text-lg text-foreground/70 mb-8">
            Não perca a chance de transformar sua saúde! O Protocolo 7D é a solução que você esperava, mas as vagas são limitadas. Garanta o seu agora e tome o controle da sua vida!
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all"
            >
              Garantir Meu Acesso Agora
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="border-2 border-primary text-primary hover:bg-primary/5 text-lg px-8 py-6 rounded-full font-semibold"
            >
              Saiba Mais
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center text-sm flex-wrap">
            <div className="flex items-center gap-2">
              <Lock className="w-5 h-5 text-primary" />
              <span>100% Privado e Discreto</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              <span>Resultados em 7 Dias</span>
            </div>
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-primary" />
              <span>Garantia de Satisfação</span>
            </div>
          </div>
        </div>
      </section>

      {/* PROBLEMA: A EPIDEMIA SILENCIOSA */}
      <section className="py-20 bg-gradient-to-b from-background to-secondary/10">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Você Não Está Sozinho: A Epidemia Silenciosa
            </h2>
            <p className="text-lg text-foreground/70">
              O que a Vergonha e o Medo Estão Escondendo
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Realidade */}
            <div className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">📊</div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">
                A Realidade
              </h3>
              <p className="text-foreground/70">
                Milhões de brasileiros, especialmente jovens entre 20 e 29 anos, convivem com o medo e as consequências das ISTs.
              </p>
            </div>

            {/* Estigma */}
            <div className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">😔</div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">
                O Estigma
              </h3>
              <p className="text-foreground/70">
                A vergonha de procurar ajuda e o medo do julgamento levam ao adiamento do tratamento.
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Consequência */}
            <div className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">⚠️</div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">
                A Consequência
              </h3>
              <p className="text-foreground/70">
                O problema se agrava, afetando sua saúde física, emocional e seus relacionamentos.
              </p>
            </div>

            {/* Insight */}
            <div className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">💡</div>
              <h3 className="text-2xl font-bold mb-3 text-foreground">
                Insight
              </h3>
              <p className="text-foreground/70">
                Você merece uma solução que respeite sua privacidade e sua urgência.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* O PREÇO DE NÃO AGIR */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              O Preço de Não Agir Agora
            </h2>
            <p className="text-lg text-foreground/70">
              Complicações que Você Pode Evitar
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Saúde Física */}
            <div className="bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl p-8">
              <div className="text-4xl mb-4">🏥</div>
              <h3 className="text-2xl font-bold mb-3">Saúde Física</h3>
              <p className="text-foreground/70">
                Agravamento dos sintomas, risco de infertilidade e complicações crônicas.
              </p>
            </div>

            {/* Saúde Emocional */}
            <div className="bg-gradient-to-br from-secondary/20 to-secondary/5 rounded-3xl p-8">
              <div className="text-4xl mb-4">😰</div>
              <h3 className="text-2xl font-bold mb-3">Saúde Emocional</h3>
              <p className="text-foreground/70">
                Ansiedade, depressão e o peso de esconder a situação.
              </p>
            </div>

            {/* Relacionamentos */}
            <div className="bg-gradient-to-br from-accent/20 to-accent/5 rounded-3xl p-8">
              <div className="text-4xl mb-4">💔</div>
              <h3 className="text-2xl font-bold mb-3">Relacionamentos</h3>
              <p className="text-foreground/70">
                O medo de transmitir e a dificuldade em manter a intimidade.
              </p>
            </div>

            {/* A Escolha */}
            <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl p-8">
              <div className="text-4xl mb-4">🔄</div>
              <h3 className="text-2xl font-bold mb-3">A Escolha</h3>
              <p className="text-foreground/70">
                Continuar no ciclo de medo e espera, ou tomar uma atitude definitiva em 7 dias?
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* LIBERDADE E CURA EM 7 DIAS */}
      <section className="py-20 bg-gradient-to-b from-background to-primary/10">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Liberdade e Cura em Apenas 7 Dias
            </h2>
            <p className="text-lg text-foreground/70">
              O Protocolo 7D Cura Caseira: Sua Saída Imediata
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* O Que É */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">✨</div>
              <h3 className="text-2xl font-bold mb-3">O Que É</h3>
              <p className="text-foreground/70">
                Um método revolucionário, 100% natural e validado, focado na eliminação rápida e discreta das ISTs.
              </p>
            </div>

            {/* Por Que 7D */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">⏱️</div>
              <h3 className="text-2xl font-bold mb-3">Por Que 7 Dias</h3>
              <p className="text-foreground/70">
                Desenvolvido para entregar resultados visíveis e duradouros em apenas uma semana.
              </p>
            </div>

            {/* Cura Caseira */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">🏠</div>
              <h3 className="text-2xl font-bold mb-3">Cura Caseira</h3>
              <p className="text-foreground/70">
                Total discrição. Você faz o tratamento no conforto e na segurança do seu lar, sem consultas ou exposição.
              </p>
            </div>

            {/* Promessa */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-2xl font-bold mb-3">Promessa</h3>
              <p className="text-foreground/70">
                Retome o controle da sua saúde e da sua vida em tempo recorde.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20 rounded-3xl p-8 border-2 border-primary/20">
            <p className="text-center text-lg text-foreground">
              <strong>A Transformação Começa Agora!</strong> Não espere mais. Cada dia que passa é um dia perdido.
            </p>
          </div>
        </div>
      </section>

      {/* O SEGREDO DA NATUREZA */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              O Segredo da Natureza Revelado
            </h2>
            <p className="text-lg text-foreground/70">
              A Ciência por Trás da Cura Rápida e Natural
            </p>
          </div>

          <div className="space-y-8">
            {/* A Descoberta */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="flex gap-6">
                <div className="text-5xl flex-shrink-0">🔬</div>
                <div>
                  <h3 className="text-2xl font-bold mb-3">A Descoberta</h3>
                  <p className="text-foreground/70">
                    Anos de pesquisa em terapias naturais resultaram em uma combinação de ingredientes que a ciência tradicional ignora.
                  </p>
                </div>
              </div>
            </div>

            {/* O Mecanismo Único */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="flex gap-6">
                <div className="text-5xl flex-shrink-0">⚡</div>
                <div>
                  <h3 className="text-2xl font-bold mb-3">O Mecanismo Único</h3>
                  <p className="text-foreground/70">
                    O Protocolo 7D ativa um processo de Desintoxicação Celular Acelerada, fortalecendo o sistema imunológico para combater as infecções de dentro para fora.
                  </p>
                </div>
              </div>
            </div>

            {/* O Poder da Combinação */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="flex gap-6">
                <div className="text-5xl flex-shrink-0">🌿</div>
                <div>
                  <h3 className="text-2xl font-bold mb-3">O Poder da Combinação</h3>
                  <p className="text-foreground/70">
                    Não é um único ingrediente, mas a sinergia de 3 elementos naturais em doses específicas que garantem a eficácia em 7 dias.
                  </p>
                </div>
              </div>
            </div>

            {/* O Resultado */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="flex gap-6">
                <div className="text-5xl flex-shrink-0">✨</div>
                <div>
                  <h3 className="text-2xl font-bold mb-3">O Resultado</h3>
                  <p className="text-foreground/70">
                    Você não precisa saber o segredo, apenas usar o resultado.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PRIVACIDADE */}
      <section className="py-20 bg-gradient-to-b from-background to-secondary/10">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Sua Privacidade é Nossa Prioridade
            </h2>
            <p className="text-lg text-foreground/70">
              O Fim da Vergonha e do Julgamento
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            {/* Sem Consultas */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">🔒</div>
              <h3 className="text-2xl font-bold mb-3">Sem Consultas</h3>
              <p className="text-foreground/70">
                Não precisa enfrentar filas, hospitais ou olhares curiosos.
              </p>
            </div>

            {/* Entrega Discreta */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">📦</div>
              <h3 className="text-2xl font-bold mb-3">Entrega Discreta</h3>
              <p className="text-foreground/70">
                O material é enviado em embalagem neutra, sem identificação do conteúdo.
              </p>
            </div>

            {/* Tratamento Silencioso */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">🏠</div>
              <h3 className="text-2xl font-bold mb-3">Tratamento Silencioso</h3>
              <p className="text-foreground/70">
                Você segue o protocolo em casa, no seu tempo, com total sigilo.
              </p>
            </div>

            {/* Foco no Público */}
            <div className="bg-white rounded-3xl p-8 shadow-md">
              <div className="text-4xl mb-4">✨</div>
              <h3 className="text-2xl font-bold mb-3">Foco no Público</h3>
              <p className="text-foreground/70">
                Especialmente desenhado para quem valoriza a discrição e a rapidez.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* A VELOCIDADE QUE SUA VIDA EXIGE */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              A Velocidade que Sua Vida Exige
            </h2>
            <p className="text-lg text-foreground/70">
              O Tempo é Seu Maior Ativo
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {/* Dias 1-2 */}
            <div className="bg-gradient-to-br from-primary/20 to-primary/5 rounded-3xl p-8 text-center">
              <div className="text-5xl font-bold text-primary mb-4">1-2</div>
              <div className="text-3xl mb-4">🔄</div>
              <h3 className="text-xl font-bold mb-3">Início da Desintoxicação</h3>
              <p className="text-foreground/70">
                Alívio dos primeiros desconfortos.
              </p>
            </div>

            {/* Dias 3-5 */}
            <div className="bg-gradient-to-br from-secondary/20 to-secondary/5 rounded-3xl p-8 text-center">
              <div className="text-5xl font-bold text-secondary mb-4">3-5</div>
              <div className="text-3xl mb-4">📉</div>
              <h3 className="text-xl font-bold mb-3">Redução Drástica</h3>
              <p className="text-foreground/70">
                Redução drástica dos sintomas visíveis e internos.
              </p>
            </div>

            {/* Dias 6-7 */}
            <div className="bg-gradient-to-br from-accent/20 to-accent/5 rounded-3xl p-8 text-center">
              <div className="text-5xl font-bold text-accent mb-4">6-7</div>
              <div className="text-3xl mb-4">✨</div>
              <h3 className="text-xl font-bold mb-3">Conclusão do Protocolo</h3>
              <p className="text-foreground/70">
                Conclusão do protocolo e a sensação de liberdade total.
              </p>
            </div>
          </div>

          <div className="bg-primary/10 rounded-3xl p-8 border-2 border-primary/20 text-center">
            <p className="text-lg text-foreground">
              <strong>🎯 O Fim da Espera:</strong> Chega de tratamentos longos e incertos. Sua transformação acontece em uma semana.
            </p>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 bg-gradient-to-b from-background to-primary/5">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Quem Já Transformou a Saúde com o 7D
            </h2>
            <p className="text-lg text-foreground/70">
              Histórias de Sucesso que Inspiram
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow">
              <p className="text-lg text-foreground/80 mb-6 italic">
                "Eu estava desesperado e morrendo de vergonha de ir ao médico. Encontrei o Protocolo 7D e foi a minha salvação. Em menos de uma semana, o problema estava resolvido, e o melhor: tudo no conforto e na discrição da minha casa. É a solução que a gente precisava!"
              </p>
              <div className="border-t border-foreground/10 pt-4">
                <h4 className="font-bold text-lg mb-1">Lucas S.</h4>
                <p className="text-sm text-foreground/60 mb-4">25 anos, São Paulo/SP</p>
                <div className="flex gap-2 flex-wrap">
                  <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full font-semibold">🔒 Discrição</span>
                  <span className="text-xs bg-secondary/10 text-secondary px-3 py-1 rounded-full font-semibold">⚡ Rapidez</span>
                  <span className="text-xs bg-accent/10 text-accent px-3 py-1 rounded-full font-semibold">😌 Alívio Emocional</span>
                </div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-3xl p-8 shadow-md hover:shadow-lg transition-shadow">
              <p className="text-lg text-foreground/80 mb-6 italic">
                "Depois de tentar várias coisas que não funcionavam, eu já estava sem esperança. O 'Cura Caseira' parecia bom demais para ser verdade, mas decidi arriscar. O resultado foi incrível. Não é só a cura, é a paz de espírito que ele devolve. Minha vida mudou completamente em 7 dias."
              </p>
              <div className="border-t border-foreground/10 pt-4">
                <h4 className="font-bold text-lg mb-1">Camila R.</h4>
                <p className="text-sm text-foreground/60 mb-4">32 anos, Belo Horizonte/MG</p>
                <div className="flex gap-2 flex-wrap">
                  <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full font-semibold">✅ Eficácia Comprovada</span>
                  <span className="text-xs bg-secondary/10 text-secondary px-3 py-1 rounded-full font-semibold">💚 Alívio Emocional</span>
                  <span className="text-xs bg-accent/10 text-accent px-3 py-1 rounded-full font-semibold">🌟 Transformação de Vida</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-12 flex justify-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            <p className="text-center text-foreground/70">
              <strong>+1.200 pessoas</strong> já transformaram suas vidas com o Protocolo 7D
            </p>
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Sua Oportunidade de Mudar de Vida
            </h2>
            <p className="text-lg text-foreground/70">
              Preço de Lançamento – Válido Apenas Hoje!
            </p>
          </div>

          <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl p-12 mb-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <p className="text-sm text-foreground/60 mb-2">PREÇO NORMAL</p>
                <p className="text-5xl font-bold text-foreground/40 line-through mb-4">
                  R$ 297,00
                </p>
                <p className="text-sm text-foreground/60 mb-6">PREÇO DE LANÇAMENTO</p>
                <p className="text-6xl font-bold text-primary mb-4">
                  R$ 97,00
                </p>
                <p className="text-lg text-foreground/70 mb-8">
                  <strong>Economize R$ 200!</strong> Oferta válida apenas hoje.
                </p>

                <div className="space-y-3 mb-8">
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-primary" />
                    <span>⚡ R$ 97,00 à vista (melhor opção)</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-primary" />
                    <span>📅 12x de R$ 9,90 (sem juros)</span>
                  </div>
                </div>

                <Button
                  size="lg"
                  className="w-full bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all"
                >
                  Garantir Meu Acesso Agora
                </Button>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-6">🎁 Bônus Inclusos</h3>
                <div className="space-y-4">
                  <div className="bg-white rounded-2xl p-6">
                    <p className="font-bold mb-2">📖 E-book "Guia de Prevenção Definitiva"</p>
                    <p className="text-sm text-foreground/70 mb-3">
                      Aprenda como evitar recorrências e manter sua saúde em dia.
                    </p>
                    <p className="text-xs text-primary font-semibold">Valor: R$ 150,00</p>
                  </div>
                </div>

                <div className="mt-8 bg-primary/10 rounded-2xl p-6 border-2 border-primary/20">
                  <p className="font-bold mb-2">✅ Garantia Risco Zero</p>
                  <p className="text-sm text-foreground/70">
                    7 dias de satisfação total ou seu dinheiro de volta. Sem perguntas, sem complicações.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 border-2 border-primary/20">
            <p className="text-center text-lg">
              <strong>⏰ Lembre-se:</strong> As vagas são limitadas para garantir o suporte de qualidade. Quanto mais tempo você espera, mais perto você fica de perder essa oportunidade.
            </p>
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-20 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20">
        <div className="container max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            A Decisão é Sua. O Tempo Está Acabando.
          </h2>

          <div className="space-y-6 mb-12">
            <p className="text-lg text-foreground/70">
              <strong>⏰ Lembre-se:</strong> As vagas são limitadas para garantir o suporte de qualidade.
            </p>
            <p className="text-lg text-foreground/70">
              <strong>⚖️ A Escolha:</strong> Continuar sofrendo em silêncio ou investir menos de R$ 10 por mês na sua liberdade e saúde?
            </p>
            <p className="text-lg text-foreground/70">
              <strong>🚀 Ação Imediata:</strong> Clique no link abaixo e garanta seu acesso antes que o preço suba ou as vagas acabem.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all"
            >
              Garantir Meu Acesso Agora
            </Button>
          </div>

          <p className="text-lg text-foreground/70 mb-4">
            <strong>🌟 Garanta o seu agora e tome o controle da sua vida!</strong>
          </p>

          <p className="text-sm text-foreground/60">
            Dúvidas? Fale conosco pelo WhatsApp: <strong>[INSERIR WHATSAPP]</strong>
          </p>
        </div>
      </section>

      {/* CTA FINAL - 3 PASSOS */}
      <section className="py-20 bg-background">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Clique e Transforme Sua Realidade
            </h2>
            <p className="text-lg text-foreground/70">
              O Caminho para a Cura em 3 Passos
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {/* Passo 1 */}
            <div className="bg-white rounded-3xl p-8 shadow-md text-center">
              <div className="text-5xl font-bold text-primary mb-4">1</div>
              <h3 className="text-2xl font-bold mb-3">Clique no Link</h3>
              <p className="text-foreground/70">
                Acesse a página de checkout agora e comece sua transformação.
              </p>
            </div>

            {/* Passo 2 */}
            <div className="bg-white rounded-3xl p-8 shadow-md text-center">
              <div className="text-5xl font-bold text-secondary mb-4">2</div>
              <h3 className="text-2xl font-bold mb-3">Preencha os Dados</h3>
              <p className="text-foreground/70">
                Escolha a melhor forma de pagamento para sua comodidade.
              </p>
            </div>

            {/* Passo 3 */}
            <div className="bg-white rounded-3xl p-8 shadow-md text-center">
              <div className="text-5xl font-bold text-accent mb-4">3</div>
              <h3 className="text-2xl font-bold mb-3">Receba o Protocolo</h3>
              <p className="text-foreground/70">
                Comece sua jornada de 7 dias para a cura imediatamente.
              </p>
            </div>
          </div>

          <div className="text-center">
            <p className="text-2xl font-bold mb-6">
              🎯 Pronto para Mudar de Vida?
            </p>
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white text-lg px-8 py-6 rounded-full font-semibold shadow-lg hover:shadow-xl transition-all"
            >
              Garantir Meu Acesso Agora
            </Button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-foreground/5 py-12">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center text-sm text-foreground/60">
            <p className="mb-4">
              © 2025 Protocolo 7D. Todos os direitos reservados.
            </p>
            <p>
              Este site não oferece aconselhamento médico. Consulte um profissional de saúde antes de iniciar qualquer tratamento.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
