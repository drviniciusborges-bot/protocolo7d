# Guia de Hospedagem no Netlify - Protocolo 7D

## 📋 Pré-requisitos

Antes de começar, você precisa ter:

1. **Conta no GitHub** (gratuita em https://github.com)
2. **Conta no Netlify** (gratuita em https://netlify.com)
3. **Git instalado** no seu computador (https://git-scm.com)

---

## 🚀 Passo a Passo para Hospedar no Netlify

### **Passo 1: Preparar o Repositório no GitHub**

1. Acesse https://github.com/new para criar um novo repositório
2. Nomeie como `protocolo7d` (ou outro nome que preferir)
3. Escolha **Public** (para que o Netlify possa acessar)
4. Clique em **Create repository**

### **Passo 2: Fazer Upload do Código para o GitHub**

Execute os seguintes comandos no terminal (na pasta do projeto):

```bash
# Inicializar git (se ainda não estiver)
git init

# Adicionar todos os arquivos
git add .

# Fazer commit
git commit -m "Inicial: Landing page Protocolo 7D"

# Adicionar o repositório remoto (substitua SEU_USUARIO e protocolo7d pelo seu)
git remote add origin https://github.com/SEU_USUARIO/protocolo7d.git

# Fazer push para o GitHub
git branch -M main
git push -u origin main
```

### **Passo 3: Conectar o Netlify ao GitHub**

1. Acesse https://app.netlify.com
2. Clique em **Add new site** → **Import an existing project**
3. Escolha **GitHub** como provedor
4. Autorize o Netlify a acessar sua conta GitHub
5. Selecione o repositório `protocolo7d`
6. Clique em **Deploy site**

### **Passo 4: Configurações Automáticas**

O Netlify vai:
- ✅ Detectar o arquivo `netlify.toml` automaticamente
- ✅ Usar o comando `pnpm build` para compilar
- ✅ Publicar a pasta `dist/public`
- ✅ Configurar redirecionamentos para SPA

**Tempo de deploy:** ~2-5 minutos

---

## 🌐 Após o Deploy

### **Seu Site Estará Disponível em:**
```
https://seu-site-aleatorio.netlify.app
```

### **Configurar Domínio Customizado (Opcional)**

1. No Netlify, vá para **Site settings** → **Domain management**
2. Clique em **Add custom domain**
3. Digite seu domínio (ex: protocolo7d.com)
4. Siga as instruções para apontar o DNS

---

## 🔄 Atualizações Futuras

Sempre que você fizer mudanças no código:

```bash
git add .
git commit -m "Descrição da mudança"
git push origin main
```

O Netlify vai **automaticamente**:
- Detectar a mudança
- Compilar o projeto
- Fazer deploy da nova versão

---

## 📊 Monitorar o Deploy

1. Acesse https://app.netlify.com
2. Clique no seu site
3. Vá para **Deploys** para ver o histórico
4. Clique em um deploy para ver logs detalhados

---

## ⚙️ Variáveis de Ambiente (Se Necessário)

Se você precisar adicionar variáveis de ambiente (como API keys):

1. No Netlify, vá para **Site settings** → **Build & deploy** → **Environment**
2. Clique em **Edit variables**
3. Adicione suas variáveis
4. Faça um novo deploy

---

## 🆘 Solução de Problemas

### **Build falha com erro de dependências**
- Certifique-se de que `pnpm` está instalado
- Delete `node_modules` e `pnpm-lock.yaml`
- Execute `pnpm install` localmente

### **Site não carrega as páginas corretamente**
- O arquivo `netlify.toml` já configura redirecionamentos para SPA
- Se ainda houver problemas, verifique os logs de deploy

### **Imagens não aparecem**
- Certifique-se de que as imagens estão em `/client/public/images/`
- Verifique os caminhos no código (devem ser `/images/nome-da-imagem.jpg`)

---

## 📝 Estrutura de Arquivos Importante

```
protocolo7d/
├── client/
│   ├── public/
│   │   └── images/          ← Suas imagens aqui
│   └── src/
│       └── pages/
│           └── Home.tsx     ← Página principal
├── netlify.toml             ← Configuração do Netlify
├── package.json
└── pnpm-lock.yaml
```

---

## ✅ Checklist Antes de Publicar

- [ ] Substitua `[INSERIR SEU LINK DE COMPRA AQUI]` pelo seu link real
- [ ] Substitua `[INSERIR WHATSAPP]` pelo seu número de WhatsApp
- [ ] Adicione as imagens do seu PDF em `/client/public/images/`
- [ ] Teste o site localmente com `pnpm dev`
- [ ] Verifique todos os links e CTAs
- [ ] Teste em mobile, tablet e desktop

---

## 🎉 Pronto!

Seu site está pronto para ser hospedado no Netlify. Siga os passos acima e seu Protocolo 7D estará online em poucos minutos!

**Dúvidas?** Consulte a documentação do Netlify: https://docs.netlify.com
